class StateEngine:
    def __init__(self, node_id):
        self.node_id = node_id
        self.state = {node_id: 0}

    def increment(self):
        self.state[self.node_id] += 1

    def merge(self, incoming):
        updated = False

        for node, value in incoming.items():
            local_val = self.state.get(node, 0)

            if value > local_val:
                self.state[node] = value
                updated = True

        if updated:
            print(" State merged:", self.state)

    def get_state(self):
        return self.state.copy()
