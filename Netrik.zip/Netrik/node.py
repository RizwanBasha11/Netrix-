import threading
import time
import argparse

from transport.udp_socket import UDPSocket
from protocol.message import encode_message, decode_message
from reliability.retransmit import ReliableSender
from sync.state_engine import StateEngine
from cluster.peer_manager import PeerManager
from config import GOSSIP_INTERVAL


parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--peers", nargs="+", required=True)
args = parser.parse_args()

PORT = args.port

PEERS = []
for p in args.peers:
    host, port = p.split(":")
    PEERS.append((host, int(port)))


udp = UDPSocket(PORT)
reliable = ReliableSender(udp)

node_id = f"node-{PORT}"
state_engine = StateEngine(node_id)
peer_manager = PeerManager(PEERS)

#RECEIVE LOOP

def receive_loop():
    while True:
        data, addr = udp.receive()
        msg = decode_message(data)

        if msg["type"] == "ACK":
            reliable.ack_received(msg["seq"])

        elif msg["type"] == "STATE":
            ack = {
                "type": "ACK",
                "seq": msg["seq"]
            }
            udp.send(encode_message(ack), addr)

            state_engine.merge(msg["payload"])


#GOSSIP LOOP

def gossip_loop():
    while True:
        time.sleep(GOSSIP_INTERVAL)

        state = state_engine.get_state()

        for peer in peer_manager.get_peers():
            packet = {
                "type": "STATE",
                "payload": state
            }

            raw = encode_message(packet)
            packet["raw"] = raw

            reliable.send(packet, peer)


# USER INPUT LOOP

def input_loop():
    while True:
        cmd = input()

        if cmd == "inc":
            state_engine.increment()
            print(" Local increment:", state_engine.get_state())


#Thread start

threading.Thread(target=receive_loop, daemon=True).start()
threading.Thread(target=reliable.retransmit_loop, daemon=True).start()
threading.Thread(target=gossip_loop, daemon=True).start()
threading.Thread(target=input_loop, daemon=True).start()


print(" Node started on port", PORT)

while True:
    time.sleep(1)
